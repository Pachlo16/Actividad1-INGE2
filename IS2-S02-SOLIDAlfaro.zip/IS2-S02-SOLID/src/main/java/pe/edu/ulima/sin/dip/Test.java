package pe.edu.ulima.sin.dip;

public class Test {
    public static void main(String[] args) {
        Usuario u = new Usuario();
        u.notificarUsuario("¡Hola Mundo!");
    }    
}
