package pe.edu.ulima.sin.dip;

public class ServicioMail {

    public void enviaEmail(String msg, String destino) {
        System.out.println("Enviando correo a " + destino + ": " + msg);
    }
}
